import nltk
nltk.download('wordnet')
nltk.download('omw-1.4')
nltk.download('stopwords')
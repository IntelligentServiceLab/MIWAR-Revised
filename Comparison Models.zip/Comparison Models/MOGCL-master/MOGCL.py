import torch
import torch as t
import torch.nn as nn
import torch.nn.functional as F
import scipy.sparse as sp
import numpy as np
from torch.nn.init import normal_
import random
from recbole.model.loss import BPRLoss, EmbLoss
from recbole.model.abstract_recommender import GeneralRecommender
from recbole.model.init import xavier_uniform_initialization
from recbole.config import Config
from recbole.data import create_dataset, data_preparation, FullSortEvalDataLoader
from recbole.utils import init_logger, init_seed, set_color, EvaluatorType
import argparse
from recbole.trainer import Trainer
from recbole.utils import early_stopping, dict2str, set_color, get_gpu_usage
from torch.nn.utils.clip_grad import clip_grad_norm_
from tqdm import tqdm
from time import time
from logging import getLogger
from recbole.config import Config
from recbole.data import create_dataset, data_preparation
from recbole.utils import init_logger, init_seed, set_color
from recbole.utils import InputType


# 定义 MOGCL 类，继承 GeneralRecommender
class MOGCL(GeneralRecommender):
    input_type = InputType.PAIRWISE  # 定义模型的输入类型为成对的交互数据（用户，物品）

    def __init__(self, config, dataset):
        super(MOGCL, self).__init__(config, dataset)  # 调用父类构造函数，初始化基本的模型

        # 加载数据集的交互矩阵
        self.interaction_matrix = dataset.inter_matrix(form='coo').astype(np.float32)

        # 加载模型的超参数
        self.latent_dim = config['embedding_size']  # 嵌入维度
        self.n_layers = config['n_layers']  # 图卷积层数
        self.reg_weight = config['reg_weight']  # 正则化权重
        self.ssl_temp = config['ssl_temp']  # 对比学习温度系数
        self.ssl_lambda = config['ssl_lambda']  # 对比学习损失的权重
        self.hyper_layers = config['hyper_layers']  # 超图卷积层数
        self.r = config['r']  # 对比学习中的参数r
        self.ssl_beta = config['ssl_beta']  # 对比学习中物品损失的权重
        self.alpha = torch.tensor(config['alpha'])  # alpha 是用于调整用户和物品嵌入的权重

        # 用户和物品的嵌入层
        self.user_embedding = torch.nn.Embedding(num_embeddings=self.n_users, embedding_dim=self.latent_dim)
        self.item_embedding = torch.nn.Embedding(num_embeddings=self.n_items, embedding_dim=self.latent_dim)

        # 定义损失函数
        self.mf_loss = BPRLoss()  # BPR (Bayesian Personalized Ranking) 损失
        self.reg_loss = EmbLoss()  # 嵌入的正则化损失
        self.restore_user_e = None  # 存储恢复的用户嵌入
        self.restore_item_e = None  # 存储恢复的物品嵌入

        # 获取归一化后的邻接矩阵
        self.acc_norm_adj_mat = self.acc_get_norm_adj_mat().to(self.device)
        self.nacc_norm_adj_mat = self.nacc_get_norm_adj_mat().to(self.device)

        # 初始化模型参数
        self.apply(xavier_uniform_initialization)  # 使用 Xavier 初始化
        self.apply(self._init_weights)  # 使用自定义的初始化函数
        self.other_parameter_name = ['restore_user_e', 'restore_item_e']  # 记录额外的参数

    # 自定义权重初始化函数
    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            normal_(module.weight.data, 0, 0.01)  # 对权重进行正态分布初始化
            if module.bias is not None:
                module.bias.data.fill_(0.0)  # 偏置初始化为0
        elif isinstance(module, nn.Embedding):
            normal_(module.weight.data, 0, 0.01)  # 嵌入层权重初始化

    # 获取归一化的邻接矩阵（标准图卷积操作）
    def acc_get_norm_adj_mat(self):
        # 构建邻接矩阵
        A = sp.dok_matrix((self.n_users + self.n_items, self.n_users + self.n_items), dtype=np.float32)
        inter_M = self.interaction_matrix  # 获取交互矩阵

        inter_M_t = self.interaction_matrix.transpose()  # 转置交互矩阵
        # 构建邻接矩阵
        data_dict = dict(zip(zip(inter_M.row, inter_M.col + self.n_users), [1] * inter_M.nnz))
        data_dict.update(dict(zip(zip(inter_M_t.row + self.n_users, inter_M_t.col), [1] * inter_M_t.nnz)))
        A._update(data_dict)

        # 计算D^(-0.5) * A * D^(-0.5) 归一化
        sumArr = (A > 0).sum(axis=1)
        diag = np.array(sumArr.flatten())[0] + 1e-7  # 加一个小常数避免除零
        diag = np.power(diag, -0.5)  # 归一化对角线元素
        self.diag = torch.from_numpy(diag).to(self.device)  # 将对角线元素转为tensor
        D = sp.diags(diag)  # 生成对角矩阵
        L = D @ A @ D  # 归一化后的邻接矩阵
        L = sp.coo_matrix(L)  # 转换为COO格式

        # 将稀疏矩阵转换为稀疏Tensor
        row = L.row
        col = L.col
        i = torch.LongTensor([row, col])
        data = torch.FloatTensor(L.data)
        SparseL = torch.sparse_coo_tensor(i, data, torch.Size(L.shape))
        return SparseL

    # 获取另一个归一化的邻接矩阵（带有r的变体）
    def nacc_get_norm_adj_mat(self):
        # 同上，但计算方式不同，使用r参数进行变换
        A = sp.dok_matrix((self.n_users + self.n_items, self.n_users + self.n_items), dtype=np.float32)
        inter_M = self.interaction_matrix
        inter_M_t = self.interaction_matrix.transpose()
        data_dict = dict(zip(zip(inter_M.row, inter_M.col + self.n_users), [1] * inter_M.nnz))
        data_dict.update(dict(zip(zip(inter_M_t.row + self.n_users, inter_M_t.col), [1] * inter_M_t.nnz)))
        A._update(data_dict)

        sumArr_left = (A > 0).sum(axis=1)
        diag_left = np.array(sumArr_left.flatten())[0] + 1e-7
        diag_left = np.power(diag_left, -self.r)  # 对左边的归一化使用r参数

        sumArr_right = (A > 0).sum(axis=1)
        diag_right = np.array(sumArr_right.flatten())[0] + 1e-7
        diag_right = np.power(diag_right, -(1 - self.r))  # 对右边的归一化使用r参数

        self.diag_left = torch.from_numpy(diag_left).to(self.device)
        self.diag_right = torch.from_numpy(diag_right).to(self.device)
        D_left = sp.diags(diag_left)
        D_right = sp.diags(diag_right)
        L = D_left @ A @ D_right
        L = sp.coo_matrix(L)
        row = L.row
        col = L.col
        i = torch.LongTensor([row, col])
        data = torch.FloatTensor(L.data)
        SparseL = torch.sparse_coo_tensor(i, data, torch.Size(L.shape))
        return SparseL

    # 获取用户和物品的“ego”嵌入，即直接的嵌入矩阵
    def get_ego_embeddings(self):
        user_embeddings = self.user_embedding.weight
        item_embeddings = self.item_embedding.weight
        ego_embeddings = torch.cat([user_embeddings, item_embeddings], dim=0)  # 连接用户和物品的嵌入
        return ego_embeddings

    # 前向传播
    def forward(self):
        # 初始化用户和物品嵌入
        acc_all_embeddings = self.get_ego_embeddings()
        acc_embeddings_list = [acc_all_embeddings]
        nacc_all_embeddings = self.get_ego_embeddings()
        nacc_embeddings_list = [nacc_all_embeddings]

        # 图卷积层
        for layer_idx in range(self.n_layers):
            acc_all_embeddings = torch.sparse.mm(self.acc_norm_adj_mat, acc_all_embeddings)  # 图卷积操作
            nacc_all_embeddings = torch.sparse.mm(self.nacc_norm_adj_mat, nacc_all_embeddings)  # 图卷积操作
            acc_embeddings_list.append(acc_all_embeddings)  # 保存每层的嵌入
            nacc_embeddings_list.append(nacc_all_embeddings)

        # 将每层的嵌入合并并平均
        lightgcn_acc_all_embeddings = torch.stack(acc_embeddings_list[:self.n_layers + 1], dim=1)
        lightgcn_acc_all_embeddings = torch.mean(lightgcn_acc_all_embeddings, dim=1)

        user_acc_all_embeddings, item_acc_all_embeddings = torch.split(lightgcn_acc_all_embeddings,
                                                                       [self.n_users, self.n_items])

        lightgcn_nacc_all_embeddings = torch.stack(nacc_embeddings_list[:self.n_layers + 1], dim=1)
        lightgcn_nacc_all_embeddings = torch.mean(lightgcn_nacc_all_embeddings, dim=1)

        user_nacc_all_embeddings, item_nacc_all_embeddings = torch.split(lightgcn_nacc_all_embeddings,
                                                                         [self.n_users, self.n_items])

        # 计算最终的用户和物品嵌入
        user_fil_emb = self.alpha * user_acc_all_embeddings + (1 - self.alpha) * user_nacc_all_embeddings
        item_fil_emb = self.alpha * item_acc_all_embeddings + (1 - self.alpha) * item_nacc_all_embeddings

        return lightgcn_acc_all_embeddings, lightgcn_nacc_all_embeddings, user_fil_emb, item_fil_emb

    # 对比学习损失
    def Ssl_loss(self, acc_embedding, nacc_embedding, user, item):
        # 计算用户和物品的对比学习损失
        acc_user_embeddings, acc_item_embeddings = torch.split(acc_embedding, [self.n_users, self.n_items])
        nacc_user_embeddings_all, nacc_item_embeddings_all = torch.split(nacc_embedding, [self.n_users, self.n_items])

        acc_user_embeddings = acc_user_embeddings[user]
        nacc_user_embeddings = nacc_user_embeddings_all[user]

        # 用户的损失计算
        norm_user_emb1 = F.normalize(acc_user_embeddings)
        norm_user_emb2 = F.normalize(nacc_user_embeddings)
        norm_all_user_emb = F.normalize(nacc_user_embeddings_all)
        pos_score_user = torch.mul(norm_user_emb1, norm_user_emb2).sum(dim=1)
        ttl_score_user = torch.matmul(norm_user_emb1, norm_all_user_emb.transpose(0, 1))
        pos_score_user = torch.exp(pos_score_user / self.ssl_temp)
        ttl_score_user = torch.exp(ttl_score_user / self.ssl_temp).sum(dim=1)
        ssl_loss_user = -torch.log(pos_score_user / ttl_score_user).sum()


        acc_item_embeddings = acc_item_embeddings[item]

        # 物品的损失计算
        norm_item_emb1 = F.normalize(acc_item_embeddings)
        norm_item_emb2 = F.normalize(nacc_item_embeddings)
        norm_all_item_emb = F.normalize(nacc_item_embeddings_all)
        pos_score_item = torch.mul(norm_item_emb1, norm_item_emb2).sum(dim=1)
        ttl_score_item = torch.matmul(norm_item_emb1, norm_all_item_emb.transpose(0, 1))
        pos_score_item = torch.exp(pos_score_item / self.ssl_temp)
        ttl_score_item = torch.exp(ttl_score_item / self.ssl_temp).sum(dim=1)
        ssl_loss_item = -torch.log(pos_score_item / ttl_score_item).sum()

        # 总的对比学习损失
        ssl_loss = self.ssl_lambda * (ssl_loss_user + self.ssl_beta * ssl_loss_item)
        return ssl_loss

    # 计算总损失
    def calculate_loss(self, interaction):
        # 清除存储的恢复变量
        if self.restore_user_e is not None or self.restore_item_e is not None:
            self.restore_user_e, self.restore_item_e = None, None

        # 获取用户，正样本物品，负样本物品
        user = interaction[self.USER_ID]
        pos_item = interaction[self.ITEM_ID]
        neg_item = interaction[self.NEG_ITEM_ID]

        # 前向传播得到嵌入
        acc_all_embeddings, nacc_all_embeddings, user_all_embeddings, item_all_embeddings = self.forward()

        # 计算对比学习损失
        ssl_loss = self.Ssl_loss(acc_all_embeddings, nacc_all_embeddings, user, pos_item)

        # 获取用户，正物品和负物品的嵌入
        u_embeddings = user_all_embeddings[user]
        pos_embeddings = item_all_embeddings[pos_item]
        neg_embeddings = item_all_embeddings[neg_item]

        # 计算BPR损失
        pos_scores = torch.mul(u_embeddings, pos_embeddings).sum(dim=1)
        neg_scores = torch.mul(u_embeddings, neg_embeddings).sum(dim=1)
        mf_loss = self.mf_loss(pos_scores, neg_scores)

        # 计算正则化损失
        u_ego_embeddings = self.user_embedding(user)
        pos_ego_embeddings = self.item_embedding(pos_item)
        neg_ego_embeddings = self.item_embedding(neg_item)
        reg_loss = self.reg_loss(u_ego_embeddings, pos_ego_embeddings, neg_ego_embeddings)

        # 返回总损失：BPR损失 + 正则化损失 + 对比学习损失
        return mf_loss + self.reg_weight * reg_loss, ssl_loss

    # 预测评分
    def predict(self, interaction):
        user = interaction[self.USER_ID]
        item = interaction[self.ITEM_ID]

        # 前向传播得到嵌入
        acc_all_embeddings, nacc_all_embeddings, user_all_embeddings, item_all_embeddings = self.forward()

        # 获取用户和物品的嵌入
        u_embeddings = user_all_embeddings[user]
        i_embeddings = item_all_embeddings[item]

        # 计算评分（点积）
        scores = torch.mul(u_embeddings, i_embeddings).sum(dim=1)
        return scores

    # 全排序预测（即为用户对所有物品的评分排序）
    def full_sort_predict(self, interaction):
        user = interaction[self.USER_ID]
        if self.restore_user_e is None or self.restore_item_e is None:
            _, _, self.restore_user_e, self.restore_item_e = self.forward()

        # 获取恢复后的嵌入
        u_embeddings = self.restore_user_e[user]

        # 通过与所有物品的嵌入点积加速计算评分
        scores = torch.matmul(u_embeddings, self.restore_item_e.transpose(0, 1))

        return scores.view(-1)

# SEHGN

This is an implementation for our paper: SEHGN: Semantic-Enhanced Heterogeneous Graph Network for Web API Recommendation

## Usage
```bash
python model/SEHGN.py
```
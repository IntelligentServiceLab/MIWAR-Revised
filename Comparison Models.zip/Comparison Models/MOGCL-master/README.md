This model is developed based on RecBole（1.2.0）, and the relevant dataset can also be obtained from RecBole.
The file MOGCL.py contains the model code, and the config.yaml file introduces the relevant parameter configuration.

